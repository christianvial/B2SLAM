<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */

Route::get('/', function () {
    return view('home');
});

Route::get('/home', function () {
    return view('home');
});

/* * *********************************************************************** */
/* * ******  Authentification ********************************************** */
/* * *********************************************************************** */


Route::get('/getLogin', function () {
    return view('authentification/formLogin');
});
Route::get('/getLogout', 'UtilisateurController@signOut');

Route::post('/login', 'UtilisateurController@signIn');

/* * *********************************************************************** */
/* * ******  Sejour ********************************************** */
/* * *********************************************************************** */


Route::get('/getListeSejour', 'SejourController@listeSejours');

/*
 * Ajout Séjour
 */

//get ajout
Route::get('/ajoutSejour', 'SejourController@ajoutSejour');

// post ajout
Route::post('/ajoutSejour', [
    'as' => 'postajoutSejour',
    'uses' => 'SejourController@postajoutSejour'
]);

Route::get('/modifierSejour/{id}', 'SejourController@modification');

//post modif
Route::post('/postmodifierSejour/{id}', [
    'as' => 'postmodifierSejour',
    'uses' => 'SejourController@postmodifierSejour'
]);
// suppression
Route::get('/supprimerSejour/{id}', 'SejourController@suppression');


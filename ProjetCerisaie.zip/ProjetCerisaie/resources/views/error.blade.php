@extends('layouts/master')
@section('content')      
@if ($erreur!= "")
<div class="alert-danger" role="alert">
    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> {{$erreur or ''}}
</div>
@endif
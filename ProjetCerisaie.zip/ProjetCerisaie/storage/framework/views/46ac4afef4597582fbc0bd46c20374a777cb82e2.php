<!doctype html>
<html lang="fr">
    <head>
        <?php echo Html::style('assets/css/bootstrap.min.css'); ?>

        <?php echo Html::style('assets/css/bootstrap.css'); ?>

        <?php echo Html::style('assets/css/monStyle.css'); ?>

        <?php echo Html::style('assets/css/jquery-ui.min.css'); ?>

    </head>
    <body class="body">
        <div class="container">
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <a id="logo_LMD" class="navbar-brand" href="#"> <img src="assets/images/logoLMD.jpg" height="50px"></a>
                        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Cerisaie</a>
                    </div>
                    <?php if(Session::get('id') == 0): ?>
                    <div class="collapse navbar-collapse" id="navbar-collapse-target">
                        <ul class="nav navbar-nav navbar-right">                             
                            <li><a href="<?php echo e(url('/getLogin')); ?>" data-toggle="collapse" data-target=".navbar-collapse.in">Se connecter</a></li>
                        </ul> 
                    </div>
                    <?php endif; ?>
                    <?php if(Session::get('id') > 0): ?>
                    <div class="nav navbar-nav">
                        <li>
                            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" 
                               aria-haspopup="true" aria-expanded="false">Séjour
                                <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li> <a class="dropdown-item"  href="<?php echo e(url('/getListeSejour')); ?>">Lister Séjours</a></li>
                                <li> <a class="dropdown-item" href="<?php echo e(url('/ajoutSejour')); ?>">Ajouter</a> </li>    
                            </ul>
                        </li>
                    </div>
                    <ul class="nav navbar-nav navbar-right">                             
                        <li><a href="<?php echo e(url('/getLogout')); ?>" data-toggle="collapse" data-target=".navbar-collapse.in">Se déconnecter</a></li>
                    </ul> 
                    <?php endif; ?>
                </div><!--/.container-fluid -->
            </nav>
            <?php echo $__env->yieldContent('content'); ?>
        </div>    
        <?php echo Html::script('assets/js/bootstrap.js'); ?>

        <?php echo Html::script('assets/js/bootstrap.min.js'); ?>

        <?php echo Html::script('assets/js/ui-bootstrap-tpls.js'); ?>

        <?php echo Html::script('assets/js/jquery-3.1.1.js'); ?>

        <?php echo Html::script('assets/js/jquery-3.3.1.min.js'); ?>

        <?php echo Html::script('assets/js/jquery-ui.min.js'); ?>

        <?php echo Html::script('assets/js/npm.js'); ?>

        <?php echo Html::script('assets/js/bootstrap-hover-dropdown.js'); ?>

        <script>

            $(document).ready(function () {
                $("#topbar-container").dropdown();
            });
            $("body").bind("click", function (e) {
                $('.dropdown-toggle, .menu').parent("li").removeClass("open");
            });
            $(".dropdown-toggle, .menu").click(function (e) {
                var $li = $(this).parent("li").toggleClass('open');
                return false;
            });
        </script>
    </body>
</html>




























<?php /**PATH C:\xampp\htdocs\vial\ProjetCerisaie\resources\views/layouts/master.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
<div>
    <h1 class="bvn">     Le camping - La Cerisaie 2019 </h1>
</div>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vial\ProjetCerisaie\resources\views/home.blade.php ENDPATH**/ ?>
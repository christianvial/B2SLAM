
<?php $__env->startSection('content'); ?>      
<?php if($erreur!= ""): ?>
<div class="alert-danger" role="alert">
    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> <?php echo e($erreur or ''); ?>

</div>
<?php endif; ?>
<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vial\ProjetCerisaie\resources\views/Error.blade.php ENDPATH**/ ?>